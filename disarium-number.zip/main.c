/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
 int n,count=0,b,sum=0,pro=1,c;
 scanf("%d",&n);
 b=n;
 c=n;
 while(n!=0){
    n=n/10;
    count++;
 }
 while(b!=0)
 {
     int rem=b%10;
     for(int i=0;i<count;i++){
         pro=pro*rem;
     }
     sum=sum+pro;
     pro=1;
     count--;
     b=b/10;
 }
 if(sum=c){
     printf("a disarium number");
    }
 else{
     printf("not a disarium number");
    }
 return 0;
}
